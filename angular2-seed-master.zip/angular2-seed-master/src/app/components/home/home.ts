import {Component} from '@angular/core';

@Component({
  selector: 'home',
  pipes: [],
  providers: [],
  directives: [],
  styleUrls: ['./home.css'],
  templateUrl: './home.html'
})
export class Home {

  constructor() {}

  ngOnInit() {

  }

}
