import {Component} from '@angular/core';
import {Http} from '@angular/http';


@Component({
  selector: 'about',
  pipes: [],
  providers: [],
  directives: [],
  styleUrls: ['./about.css'],
  templateUrl: './about.html'
})
export class About {

  constructor(http: Http) {

  }

  ngOnInit() {

  }
}
